package com.example.consumer.app;


import com.example.consumer.service.CalculatorRemoteImpl;
import com.example.provider.service.Calculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 客户端应用层发起 RPC
 */
public class ConsumerApp {
//    private static Logger log = LoggerFactory.getLogger(ConsumerApp.class);

    public static void main(String[] args) {
        Calculator calculator = new CalculatorRemoteImpl();
        int result = calculator.add(1,2);

//        log.info("result is {}",result);
        System.out.println("result is "+result);
    }
}
