package com.example.consumer.service;

import com.example.provider.service.Calculator;
import com.example.request.CalculateRpcRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * CalculatorRemoteImpl:封装RPC逻辑，是客户端进行远程调用时感觉不到麻烦
 */
public class CalculatorRemoteImpl implements Calculator {

    public static final int PORT = 1234;
//    private static Logger log = LoggerFactory.getLogger(CalculatorRemoteImpl.class);

    @Override
    public int add(int a, int b) {
        //查找到可调用的服务实例列表
        List<String> addressList = lookupProviders();

        //确定要调用的实例地址
        String address = chooseTarget(addressList);

        //Socket通信
        try {
            Socket socket = new Socket(address,PORT);
            //将请求序列化
            CalculateRpcRequest calculateRpcRequest = generateRequest(a,b);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());

            //将请求发给服务提供方
            objectOutputStream.writeObject(calculateRpcRequest);

            //将响应体反序列化
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
            Object response = objectInputStream.readObject();

            System.out.println("response is " + response);
//            log.info("response is {}",response);

            if (response instanceof Integer){
                return (Integer)response;
            } else {
                throw new InternalError();
            }

        } catch (Exception e) {
//            log.error("fail",e);
            e.printStackTrace();
            throw new InternalError();
        }
    }



    /**
     * 生成 RPC请求
     * @param a
     * @param b
     * @return
     */
    private CalculateRpcRequest generateRequest(int a, int b) {
        CalculateRpcRequest calculateRpcRequest = new CalculateRpcRequest();
        calculateRpcRequest.setA(a);
        calculateRpcRequest.setB(b);
        calculateRpcRequest.setMethod("add");
//        System.out.println("calculateRpcRequest = " + calculateRpcRequest);
        return calculateRpcRequest;
    }


    /*
     * 分布式应用下，一个服务可能有多个实例
     * 比如：ServiceA，可能有ip地址：198.168.1.11  198.168.1.13 两个实例
     * 在分布式应用下，通常会有一个服务注册中心，来提供查询实例列表的功能。
     */
    /**
     * 寻找要调用的服务实例列表
     * @return  可用ip地址列表
     */
    private List<String> lookupProviders() {
        List<String> strings = new ArrayList<>();
        strings.add("127.0.0.1");
//        System.out.println("strings = " + strings);
        return strings;
    }

    /**
     * 查询到实例列表后，确定需要调用哪个实例
     * @param providersAddressList
     * @return
     */
    private String chooseTarget(List<String> providersAddressList) {
        if (providersAddressList == null || providersAddressList.size() == 0){
            throw new IllegalArgumentException();
        }
//        System.out.println("providersAddressList.get(0) = " + providersAddressList.get(0));
        return providersAddressList.get(0);
    }
}
