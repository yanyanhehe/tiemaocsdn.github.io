package com.example.provider.service;

public interface Calculator {
    int add(int a,int b);
}
