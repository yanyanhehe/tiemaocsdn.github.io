package com.example.provider.app;

import com.example.provider.service.Calculator;
import com.example.provider.service.CalculatorImpl;
import com.example.request.CalculateRpcRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ProviderApp {

//    private static Logger log = (Logger) LoggerFactory.getLogger(ProviderApp.class);
    private Calculator calculator = new CalculatorImpl();

    public static void main(String[] args) throws IOException {
        new ProviderApp().start();
    }

    private void start() throws IOException {
        ServerSocket serverSocket = new ServerSocket(1234);

        try {
            //接收Client端发过来的请求
            while (true){
                Socket socket = serverSocket.accept();
                try {
                    //将请求反序列化
                    ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                    Object object = objectInputStream.readObject();

                    System.out.println("request is " +object);
//                    log.info("request is {} ",object);

                    //调用服务执行
                    int result = 0;
                    if (object instanceof CalculateRpcRequest){
                        CalculateRpcRequest calculateRpcRequest = (CalculateRpcRequest) object;
                        if ("add".equals(calculateRpcRequest.getMethod())){
                            result = calculator.add(calculateRpcRequest.getA(),calculateRpcRequest.getB());
                        }else {
                            throw new UnsupportedOperationException();
                        }
                    }

                    //序列化执行结果并返回给Client
                    ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                    objectOutputStream.writeObject(new Integer(result));

                } catch (Exception e) {
                    e.printStackTrace();
//                    log.error("fail",e);
                }finally {
                    socket.close();
                }
            }
        } finally {
            serverSocket.close();
        }
    }

}
