package com.example.request;

import java.io.Serializable;

public class CalculateRpcRequest implements Serializable {
    private String Method;
    private int a;
    private int b;

    public String getMethod() {
        return Method;
    }

    public void setMethod(String method) {
        Method = method;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    @Override
    public String toString() {
        return "CalculateRpcRequest{" +
                "Method='" + Method + '\'' +
                ", a=" + a +
                ", b=" + b +
                '}';
    }
}
