# simple-rpc
A simple rpc framework.