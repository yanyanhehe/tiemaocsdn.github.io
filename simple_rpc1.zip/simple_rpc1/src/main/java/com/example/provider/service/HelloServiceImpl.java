package com.example.provider.service;

/**
 * 接口实现服务
 */
public class HelloServiceImpl implements HelloService {
    @Override
    public String hello(String name) {
        return "Hello " + name;
    }
}
