package com.example.provider;

import com.example.framwork.RpcFramework;
import com.example.provider.service.HelloService;
import com.example.provider.service.HelloServiceImpl;

/**
 * 暴露服务
 */
public class RpcProvider {
    public static void main(String[] args) throws Exception {
        HelloService service = new HelloServiceImpl();
        RpcFramework.export(service,1234);
    }
}
