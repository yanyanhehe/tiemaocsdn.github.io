package com.example.provider.service;

/**
 * 定义服务接口
 */
public interface HelloService {
    String hello(String name);
}
